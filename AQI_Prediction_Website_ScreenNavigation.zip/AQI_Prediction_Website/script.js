const $ = id => document.getElementById(id);
const form = $('aqiForm');
if (form) form.addEventListener('submit', function(event) {
  event.preventDefault();
  const values = {pm25:Number($('pm25').value),pm10:Number($('pm10').value),no2:Number($('no2').value),so2:Number($('so2').value),co:Number($('co').value),o3:Number($('o3').value),temp:Number($('temp').value),humidity:Number($('humidity').value),wind:Number($('wind').value)};
  // Illustrative score only; replace with predictions from a trained model for real results.
  let score=values.pm25*1.15+values.pm10*.45+values.no2*.55+values.so2*.4+values.co*12+values.o3*.25+Math.max(0,values.humidity-50)*.12-values.wind*1.4;
  score=Math.max(0,Math.min(500,Math.round(score)));
  let band,title,message;
  if(score<=50){band='Good';title='Good (demo estimate)';message='The illustrative score falls in the good range.'}
  else if(score<=100){band='Moderate';title='Moderate (demo estimate)';message='The illustrative score falls in the moderate range.'}
  else if(score<=150){band='Unhealthy for sensitive groups';title='Sensitive groups: caution';message='The illustrative score is elevated; check official local AQI information.'}
  else if(score<=200){band='Unhealthy';title='Unhealthy (demo estimate)';message='The illustrative score is high; check official local AQI information.'}
  else if(score<=300){band='Very unhealthy';title='Very unhealthy (demo estimate)';message='The illustrative score is very high; check official local AQI information.'}
  else{band='Hazardous';title='Hazardous (demo estimate)';message='The illustrative score is very high; check official local AQI information.'}
  $('aqiValue').textContent=score;$('resultTitle').textContent=title;$('resultText').textContent=message+' Category: '+band+'.';
});

// Demo login: any valid email and non-empty password opens the dashboard.
const loginForm=$('loginForm');
function showApp(){ $('loginScreen').style.display='none';$('appShell').style.display='';showScreen('dashboard');window.scrollTo(0,0); }
if(loginForm) loginForm.addEventListener('submit',e=>{e.preventDefault();showApp();});
const logout=$('logoutBtn');if(logout)logout.addEventListener('click',()=>{ $('appShell').style.display='none';$('loginScreen').style.display='grid';window.scrollTo(0,0); });
// Sidebar navigation switches screens in place instead of scrolling down the long dashboard.
const screenTitle = document.querySelector('.topbar h1');
const screenCrumb = document.querySelector('.crumb');
const welcome = document.querySelector('.welcome-row');
const stats = document.querySelector('.stats-grid');
const airPanel = $('airquality');
const predictionPanel = $('prediction');
const modelPanel = $('reports');
const bottomGrid = document.querySelector('.bottom-grid');
const featurePanel = $('about');
const additionalGrid = $('additional');
const footer = document.querySelector('footer');
const screenParts = [welcome, stats, airPanel, predictionPanel, modelPanel, bottomGrid, additionalGrid, footer].filter(Boolean);
function showScreen(name) {
  screenParts.forEach(part => part.classList.add('view-hidden'));
  if (bottomGrid) bottomGrid.classList.add('view-hidden');
  if (name === 'dashboard') {
    [welcome, stats, airPanel].filter(Boolean).forEach(part => part.classList.remove('view-hidden'));
  } else if (name === 'airquality') {
    airPanel?.classList.remove('view-hidden');
  } else if (name === 'prediction') {
    predictionPanel?.classList.remove('view-hidden');
  } else if (name === 'reports') {
    modelPanel?.classList.remove('view-hidden');
  } else if (name === 'additional') {
    additionalGrid?.classList.remove('view-hidden');
  } else if (name === 'about') {
    bottomGrid?.classList.remove('view-hidden');
    // In the About screen, show only the project information card.
    const workflowCard = bottomGrid?.children[0];
    if (workflowCard) workflowCard.classList.add('view-hidden');
    featurePanel?.classList.remove('view-hidden');
  }
  // Reset nested cards when navigating away from About.
  if (name !== 'about' && bottomGrid?.children[0]) bottomGrid.children[0].classList.remove('view-hidden');
  const labels = {dashboard:'Air Quality Dashboard',airquality:'Live AQI Overview',prediction:'AQI Prediction',reports:'Reports & Models',additional:'Additional Screens',about:'About Project'};
  if (screenTitle) screenTitle.textContent = labels[name] || 'Air Quality Dashboard';
  if (screenCrumb) screenCrumb.innerHTML = 'WORKSPACE / <b>' + (labels[name] || 'OVERVIEW').toUpperCase() + '</b>';
  document.querySelectorAll('.nav-link').forEach(item => item.classList.toggle('active', item.getAttribute('href') === '#' + name));
  window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('.nav-link').forEach(link => link.addEventListener('click', event => {
  event.preventDefault();
  showScreen(link.getAttribute('href').slice(1));
}));
// Dashboard brand returns to the Home/Dashboard screen.
document.querySelector('.brand')?.addEventListener('click', event => { event.preventDefault(); showScreen('dashboard'); });
// Additional-screen cards open their corresponding screen, too.
document.querySelectorAll('.screen-card').forEach(card => card.addEventListener('click', event => {
  event.preventDefault();
  const href = card.getAttribute('href') || '#additional';
  const target = href === '#airquality' ? 'airquality' : href === '#reports' ? 'reports' : 'about';
  showScreen(target);
}));

const compact=$('compactToggle');if(compact)compact.addEventListener('change',()=>document.body.classList.toggle('compact-mode',compact.checked));
const notices=$('noticeToggle');if(notices)notices.addEventListener('change',()=>document.body.classList.toggle('hide-notices',!notices.checked));
