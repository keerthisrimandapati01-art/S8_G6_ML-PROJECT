AIRWISE AI — AQI PREDICTION WEBSITE

Screens included:
1. Login Page — demo sign-in screen inspired by the provided reference.
2. Dashboard (Home Page) — dataset overview, air quality overview and model metrics.
3. Prediction Page — inputs for PM2.5, PM10, NO2, SO2, CO, O3, temperature, humidity and wind speed.
4. Additional Screens — Live AQI overview, Reports & Models, Project Information and Quick Settings.

HOW TO RUN
1. Extract this ZIP file.
2. Open the AQI_Prediction_Website folder in VS Code.
3. Open index.html with Live Server, or double-click index.html to open it in a browser.
4. At the login screen, use any valid email address and a non-empty password. This is a front-end demo login only.

IMPORTANT MODEL NOTE
The displayed Ridge/Lasso metrics are from the supplied project results. The interactive AQI result is an illustrative formula, not a prediction from a trained Ridge/Lasso model. Connect a Python backend and saved trained model to produce genuine model predictions. Login is not secure authentication and should not be used for real accounts.
